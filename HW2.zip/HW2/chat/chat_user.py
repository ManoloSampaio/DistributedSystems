class ChatUser():
    def __init__(self,user_nickname,server_ip,server_port):
        self.nickname = user_nickname
        self.server_ip = server_ip
        self.server_port = server_port
    
        
        